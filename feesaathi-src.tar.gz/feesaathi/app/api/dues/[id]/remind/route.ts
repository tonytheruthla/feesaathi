import { NextResponse } from "next/server";
import { dues, students, reminderLogs } from "@/lib/db";
import { getCurrentTutor } from "@/lib/auth";
import { reminderMessage, waShareLink, monthLabel } from "@/lib/messages";
import { whatsappConfigured, sendWhatsAppTemplate } from "@/lib/whatsapp";
import { upiDeepLink } from "@/lib/payments";

// POST /api/dues/:id/remind
// If WhatsApp Cloud API is configured → sends automatically.
// Otherwise → returns a wa.me share link for one-tap manual send.
export async function POST(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const tutor = await getCurrentTutor();
  if (!tutor) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const due = dues.byId(params.id);
  const student = due ? students.byId(due.studentId) : undefined;
  if (!due || !student || student.tutorId !== tutor.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (due.status === "PAID") {
    return NextResponse.json({ error: "Already paid" }, { status: 400 });
  }

  const label = monthLabel(due.month);
  const payUrl =
    due.razorpayLinkUrl ||
    (tutor.upiId
      ? upiDeepLink({
          upiId: tutor.upiId,
          payeeName: tutor.businessName || tutor.name,
          amount: due.amount,
          note: `Fee ${student.name} ${label}`,
        })
      : "(pay link not set — add your UPI ID in Settings)");

  if (whatsappConfigured()) {
    const result = await sendWhatsAppTemplate({
      toPhone: student.parentPhone,
      parentName: student.parentName,
      studentName: student.name,
      monthLabel: label,
      amount: due.amount,
      payUrl,
    });
    reminderLogs.create({
      dueId: due.id,
      channel: "WHATSAPP_API",
      status: result.ok ? "SENT" : "FAILED",
      detail: result.detail,
    });
    if (!result.ok) {
      return NextResponse.json(
        { error: `WhatsApp send failed: ${result.detail}` },
        { status: 502 }
      );
    }
    return NextResponse.json({ ok: true, channel: "WHATSAPP_API" });
  }

  // Fallback: one-tap share via tutor's own WhatsApp
  const text = reminderMessage(tutor.msgLanguage, {
    parentName: student.parentName,
    studentName: student.name,
    monthLabel: label,
    amount: due.amount,
    tutorName: tutor.name,
    businessName: tutor.businessName,
    payUrl,
  });
  const shareUrl = waShareLink(student.parentPhone, text);
  reminderLogs.create({
    dueId: due.id,
    channel: "SHARE_LINK",
    status: "SENT",
    detail: "",
  });
  return NextResponse.json({ ok: true, channel: "SHARE_LINK", shareUrl });
}
