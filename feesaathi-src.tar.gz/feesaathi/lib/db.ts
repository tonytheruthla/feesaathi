import Database from "better-sqlite3";
import path from "path";
import { randomBytes } from "crypto";

// --- Types ---

export type Tutor = {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  businessName: string;
  phone: string;
  upiId: string;
  msgLanguage: string;
  createdAt: string;
};

export type Student = {
  id: string;
  tutorId: string;
  name: string;
  parentName: string;
  parentPhone: string;
  monthlyFee: number;
  dueDay: number;
  batch: string;
  active: number; // sqlite boolean
  notes: string;
  createdAt: string;
};

export type Due = {
  id: string;
  studentId: string;
  month: string;
  amount: number;
  status: "PENDING" | "PAID";
  paidAt: string | null;
  paymentMethod: string;
  razorpayLinkId: string;
  razorpayLinkUrl: string;
  createdAt: string;
};

export type ReminderLog = {
  id: string;
  dueId: string;
  channel: string;
  status: string;
  detail: string;
  sentAt: string;
};

// --- Connection (singleton across hot reloads) ---

const globalForDb = globalThis as unknown as { __feesaathiDb?: Database.Database };

function connect() {
  const file =
    process.env.DATABASE_FILE || path.join(process.cwd(), "feesaathi.db");
  const db = new Database(file);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.exec(`
    CREATE TABLE IF NOT EXISTS Tutor (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      passwordHash TEXT NOT NULL,
      name TEXT NOT NULL,
      businessName TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      upiId TEXT NOT NULL DEFAULT '',
      msgLanguage TEXT NOT NULL DEFAULT 'hinglish',
      createdAt TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS Student (
      id TEXT PRIMARY KEY,
      tutorId TEXT NOT NULL REFERENCES Tutor(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      parentName TEXT NOT NULL DEFAULT '',
      parentPhone TEXT NOT NULL,
      monthlyFee INTEGER NOT NULL,
      dueDay INTEGER NOT NULL DEFAULT 5,
      batch TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1,
      notes TEXT NOT NULL DEFAULT '',
      createdAt TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS Due (
      id TEXT PRIMARY KEY,
      studentId TEXT NOT NULL REFERENCES Student(id) ON DELETE CASCADE,
      month TEXT NOT NULL,
      amount INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      paidAt TEXT,
      paymentMethod TEXT NOT NULL DEFAULT '',
      razorpayLinkId TEXT NOT NULL DEFAULT '',
      razorpayLinkUrl TEXT NOT NULL DEFAULT '',
      createdAt TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(studentId, month)
    );
    CREATE TABLE IF NOT EXISTS ReminderLog (
      id TEXT PRIMARY KEY,
      dueId TEXT NOT NULL REFERENCES Due(id) ON DELETE CASCADE,
      channel TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'SENT',
      detail TEXT NOT NULL DEFAULT '',
      sentAt TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  return db;
}

export const db = globalForDb.__feesaathiDb || connect();
if (process.env.NODE_ENV !== "production") globalForDb.__feesaathiDb = db;

export function cuid() {
  return randomBytes(12).toString("hex");
}

// --- Tutor ---

export const tutors = {
  byEmail: (email: string) =>
    db.prepare("SELECT * FROM Tutor WHERE email = ?").get(email) as
      | Tutor
      | undefined,
  byId: (id: string) =>
    db.prepare("SELECT * FROM Tutor WHERE id = ?").get(id) as Tutor | undefined,
  create: (t: Omit<Tutor, "id" | "createdAt" | "phone" | "msgLanguage"> & {
    phone?: string;
  }) => {
    const id = cuid();
    db.prepare(
      `INSERT INTO Tutor (id, email, passwordHash, name, businessName, phone, upiId)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(id, t.email, t.passwordHash, t.name, t.businessName, t.phone || "", t.upiId);
    return tutors.byId(id)!;
  },
  update: (id: string, data: Partial<Tutor>) => {
    const allowed = ["name", "businessName", "phone", "upiId", "msgLanguage"];
    const keys = Object.keys(data).filter((k) => allowed.includes(k));
    if (keys.length === 0) return tutors.byId(id)!;
    const sets = keys.map((k) => `${k} = ?`).join(", ");
    db.prepare(`UPDATE Tutor SET ${sets} WHERE id = ?`).run(
      ...keys.map((k) => (data as Record<string, unknown>)[k]),
      id
    );
    return tutors.byId(id)!;
  },
};

// --- Students ---

export const students = {
  list: (tutorId: string) =>
    db
      .prepare(
        "SELECT * FROM Student WHERE tutorId = ? ORDER BY active DESC, name ASC"
      )
      .all(tutorId) as Student[],
  listActive: (tutorId: string) =>
    db
      .prepare("SELECT * FROM Student WHERE tutorId = ? AND active = 1")
      .all(tutorId) as Student[],
  byId: (id: string) =>
    db.prepare("SELECT * FROM Student WHERE id = ?").get(id) as
      | Student
      | undefined,
  create: (s: {
    tutorId: string;
    name: string;
    parentName: string;
    parentPhone: string;
    monthlyFee: number;
    dueDay: number;
    batch: string;
    notes: string;
  }) => {
    const id = cuid();
    db.prepare(
      `INSERT INTO Student (id, tutorId, name, parentName, parentPhone, monthlyFee, dueDay, batch, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id, s.tutorId, s.name, s.parentName, s.parentPhone,
      s.monthlyFee, s.dueDay, s.batch, s.notes
    );
    return students.byId(id)!;
  },
  update: (id: string, data: Record<string, unknown>) => {
    const allowed = [
      "name", "parentName", "parentPhone", "monthlyFee",
      "dueDay", "batch", "notes", "active",
    ];
    const keys = Object.keys(data).filter((k) => allowed.includes(k));
    if (keys.length === 0) return students.byId(id)!;
    const sets = keys.map((k) => `${k} = ?`).join(", ");
    db.prepare(`UPDATE Student SET ${sets} WHERE id = ?`).run(
      ...keys.map((k) => {
        const v = data[k];
        return typeof v === "boolean" ? (v ? 1 : 0) : v;
      }),
      id
    );
    return students.byId(id)!;
  },
  remove: (id: string) => db.prepare("DELETE FROM Student WHERE id = ?").run(id),
};

// --- Dues ---

export type DueWithStudent = Due & {
  student: Student;
  reminders: ReminderLog[];
};

export const dues = {
  boardForMonth: (tutorId: string, month: string): DueWithStudent[] => {
    const rows = db
      .prepare(
        `SELECT d.* FROM Due d
         JOIN Student s ON s.id = d.studentId
         WHERE s.tutorId = ? AND d.month = ?
         ORDER BY d.status DESC, d.createdAt ASC`
      )
      .all(tutorId, month) as Due[];
    return rows.map((d) => ({
      ...d,
      student: students.byId(d.studentId)!,
      reminders: db
        .prepare(
          "SELECT * FROM ReminderLog WHERE dueId = ? ORDER BY sentAt DESC LIMIT 1"
        )
        .all(d.id) as ReminderLog[],
    }));
  },
  byId: (id: string) =>
    db.prepare("SELECT * FROM Due WHERE id = ?").get(id) as Due | undefined,
  byStudentMonth: (studentId: string, month: string) =>
    db
      .prepare("SELECT * FROM Due WHERE studentId = ? AND month = ?")
      .get(studentId, month) as Due | undefined,
  byRazorpayLinkId: (linkId: string) =>
    db.prepare("SELECT * FROM Due WHERE razorpayLinkId = ?").get(linkId) as
      | Due
      | undefined,
  create: (studentId: string, month: string, amount: number) => {
    const id = cuid();
    db.prepare(
      "INSERT INTO Due (id, studentId, month, amount) VALUES (?, ?, ?, ?)"
    ).run(id, studentId, month, amount);
    return dues.byId(id)!;
  },
  setRazorpayLink: (id: string, linkId: string, url: string) =>
    db
      .prepare("UPDATE Due SET razorpayLinkId = ?, razorpayLinkUrl = ? WHERE id = ?")
      .run(linkId, url, id),
  markPaid: (id: string, method: string) =>
    db
      .prepare(
        "UPDATE Due SET status = 'PAID', paidAt = datetime('now'), paymentMethod = ? WHERE id = ?"
      )
      .run(method, id),
  markPending: (id: string) =>
    db
      .prepare(
        "UPDATE Due SET status = 'PENDING', paidAt = NULL, paymentMethod = '' WHERE id = ?"
      )
      .run(id),
};

// --- Reminder logs ---

export const reminderLogs = {
  create: (l: { dueId: string; channel: string; status: string; detail: string }) => {
    db.prepare(
      "INSERT INTO ReminderLog (id, dueId, channel, status, detail) VALUES (?, ?, ?, ?, ?)"
    ).run(cuid(), l.dueId, l.channel, l.status, l.detail);
  },
};
